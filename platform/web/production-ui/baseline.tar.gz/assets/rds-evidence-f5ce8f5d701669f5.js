const evidence = {"serviceScope": "f3ca6673cf3166f900c8cf8fccd0e431eb5337cbc023085884bcb88dfdc56d43", "rule": "MAP-SEC-002", "serial": 21, "failures": 5, "windowSeconds": 60, "detectedAt": "2026-11-07T07:15:45.483513+00:00", "normalFindings": 0, "beforeThresholdFindings": 0, "wazuh": {"rule": "100521", "serial": 21, "version": "4.14.10", "detectedAt": "2026-11-07T07:41:30.575000+00:00", "guardDutyObservedAt": "2026-11-07T07:41:01.040904+00:00", "failures": 5, "windowSeconds": 60, "otherSourceFindings": 0}};
const cardSelector = "[data-delta-rds-evidence]";
const mapSelector = "#workspace-content section.migration-panel > section.migration-map";
const workflowSelector = "#workspace-content section.deployment-panel";
const migrationRoute = /^#\/migration\/([a-f0-9-]{36})$/i;
const hex = (buffer) =>
  [...new Uint8Array(buffer)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
const date = new Intl.DateTimeFormat("ko-KR", {
  dateStyle: "medium",
  timeStyle: "medium",
  timeZone: "Asia/Seoul",
});

function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function step(title, badge, description) {
  const item = element("li");
  item.append(
    element("h4", title),
    element("span", badge, "rds-evidence-badge"),
    element("p", description),
  );
  return item;
}

function formatTime(timestamp) {
  return `${date.format(new Date(timestamp))} KST`;
}

function wireLiveValidation(card, result) {
  const serviceId = migrationRoute.exec(location.hash)[1];
  const endpoint = `/api/v1/services/${serviceId}/rds-wazuh`;
  const button = element("button", "Wazuh 검증 다시 실행");
  button.type = "button";
  button.disabled = true;
  const status = element("p", "검증 작업자 연결 확인 중");
  status.setAttribute("role", "status");
  const controls = element("div", "", "rds-evidence-controls");
  controls.append(button, status);
  card.append(controls);
  let submitting = false;
  let ready = false;
  let running = false;
  let notice = "";

  async function request(path, options) {
    const response = await fetch(path, { credentials: "same-origin", ...options });
    if (!response.ok) throw new Error(String(response.status));
    return response.json();
  }

  function updateButton() {
    button.disabled = submitting || running || !ready;
  }

  async function refresh() {
    if (!card.isConnected) return;
    try {
      const data = await request(endpoint);
      ready = data.worker_ready;
      running = ["queued", "running"].includes(data.run?.status);
      if (data.finding) {
        result.querySelector("span").textContent = "새 실측 경보 1건";
        result.querySelector("p").textContent =
          `규칙 ${data.finding.rule} · 같은 출발지 ${data.finding.failures}회 실패 (${(data.finding.span_ms / 1000).toFixed(1)}초) · ${formatTime(data.finding.detected_at)}`;
      }
      status.textContent = notice || ({
        queued: "온프레미스 작업자에 검증을 요청했습니다.",
        running: "격리된 PostgreSQL에서 로그인 실패를 재현하고 실제 Wazuh 경보를 확인 중입니다.",
        verified: "이 실행의 실제 Wazuh 경보를 비교 카드에 반영했습니다.",
        failed: "이번 검증에서 경보를 확인하지 못했습니다. 마지막 성공 기록을 표시합니다.",
      }[data.run?.status] ?? (ready ? "검증 준비 완료" : "온프레미스 작업자 연결 대기"));
    } catch {
      ready = false;
      status.textContent = "검증 상태를 불러오지 못했습니다. 로그인과 연결 상태를 확인하세요.";
    }
    updateButton();
  }

  button.addEventListener("click", async () => {
    if (button.disabled) return;
    notice = "";
    submitting = true;
    updateButton();
    try {
      const { csrf_token } = await request("/api/v1/auth/session");
      await request(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Platform-Request": "1", "X-CSRF-Token": csrf_token },
        body: JSON.stringify({ id: crypto.randomUUID() }),
      });
    } catch {
      notice = "검증을 시작하지 못했습니다. 로그인과 작업자 연결을 확인한 뒤 다시 시도하세요.";
    } finally {
      submitting = false;
      await refresh();
    }
  });

  async function poll() {
    if (!card.isConnected) return;
    if (!submitting) await refresh();
    if (card.isConnected) window.setTimeout(poll, running ? 1000 : 3000);
  }
  window.setTimeout(poll, 0);
}

function buildWazuhCard(card, wazuh) {
  const comparison = element("ul", "", "rds-evidence-steps rds-evidence-comparison");
  comparison.setAttribute("aria-label", "GuardDuty와 Wazuh 비교");
  const result = step("온프레미스 · Wazuh Manager", "실측 경보 1건", `규칙 ${wazuh.rule} · 같은 출발지 ${wazuh.windowSeconds}초 내 ${wazuh.failures}회 실패 · ${formatTime(wazuh.detectedAt)}`);
  comparison.append(
    step("AWS · GuardDuty RDS Protection", "AWS API 확인 · 활성", `로그인 맥락 기반 이상 탐지 · ${formatTime(wazuh.guardDutyObservedAt)} 확인`),
    result,
  );
  const flow = element("ol", "", "rds-evidence-steps");
  flow.append(
    step("1. 차분에서 공백 발견", "MAP-SEC-002", `GuardDuty RDS 로그인 보호 · AWS Terraform state #${wazuh.serial}`),
    step("2. Wazuh에 PostgreSQL 연결", "별도 서비스", `k3s 테스트 DB의 인증 실패 JSON → Wazuh Manager ${wazuh.version}`),
    step("3. 같은 출발지 5회째 경보", "부분 대응 실측", `정상 로그인·4회 실패·다른 출발지 1회 추가는 모두 경보 ${wazuh.otherSourceFindings}건`),
  );
  card.append(comparison, flow);
  wireLiveValidation(card, result);
  card.append(element("p", "AWS는 보호 설정 관측, Wazuh는 샌드박스 실제 경보입니다. 로그인 맥락 분석과 DB 유출 탐지는 별도 확인이 필요합니다."));
  card.append(element("p", `기존 delta-rds-watch 검증 · 경보 1건 · ${formatTime(evidence.detectedAt)}`));
}

function buildCard() {
  const card = element("section", "", "panel rds-evidence");
  card.setAttribute("data-delta-rds-evidence", "");
  card.setAttribute("aria-labelledby", "delta-rds-evidence-title");
  const heading = element("h3", "GuardDuty 보안 기능 대응");
  heading.id = "delta-rds-evidence-title";
  const direction = element("p", "AWS → 온프레미스 · 저장된 k3s 샌드박스 실측");
  if (evidence.wazuh) {
    card.append(heading, direction);
    buildWazuhCard(card, evidence.wazuh);
    return card;
  }
  const steps = element("ol", "", "rds-evidence-steps");
  steps.append(
    step(
      "1. 차분에서 공백 발견",
      "대응 공백",
      `GuardDuty RDS 로그인 보호 · ${evidence.rule} · AWS Terraform state #${evidence.serial}`,
    ),
    step(
      "2. 온프레미스 탐지 서비스 연결",
      "연결 검증",
      "격리된 PostgreSQL → 인증 실패 이벤트 → delta-rds-watch (k3s ClusterIP)",
    ),
    step(
      "3. 실제 경보 확인",
      "경보 1건",
      `같은 출발지에서 ${evidence.windowSeconds}초 내 ${evidence.failures}회 실패 · ${formatTime(evidence.detectedAt)}`,
    ),
  );
  const detail = element("p", `정상 로그인 경보 ${evidence.normalFindings}건 · ${evidence.failures - 1}회 실패 경보 ${evidence.beforeThresholdFindings}건 · 검증 후 샌드박스 정리 완료`);
  const boundary = element("p", "검증 범위는 반복 로그인 실패 탐지입니다. 로그인 맥락 분석과 DB 유출 탐지는 별도 확인이 필요합니다. 전체 차분 판정은 확인 필요입니다.");
  card.append(heading, direction, steps, detail, boundary);
  return card;
}

let scheduled = false;
let authorizedRoute;

async function sync() {
  const route = location.hash;
  const id = migrationRoute.exec(route)?.[1].toLowerCase();
  if (id && authorizedRoute?.id !== id) {
    const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(id));
    if (location.hash !== route) return;
    authorizedRoute = { id, matches: hex(digest) === evidence.serviceScope };
  }
  const card = document.querySelector(cardSelector);
  const map = id && authorizedRoute?.matches &&
    (document.querySelector(mapSelector) ?? document.querySelector(workflowSelector));
  if (!map) {
    card?.remove();
    return;
  }
  if (!card) map.after(buildCard());
}

function schedule() {
  if (scheduled) return;
  scheduled = true;
  requestAnimationFrame(() => {
    scheduled = false;
    void sync();
  });
}

window.addEventListener("hashchange", schedule);
const root = document.querySelector("#root");
if (root) new MutationObserver(schedule).observe(root, { childList: true, subtree: true });
schedule();
